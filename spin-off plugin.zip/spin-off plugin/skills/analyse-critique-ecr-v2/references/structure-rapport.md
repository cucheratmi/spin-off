# Structure du rapport MarkDown d'analyse critique

Format cible : `.md`. Style sobre, orienté décideur HTA.

## Page de garde

- Titre : « Analyse critique de l'essai [NOM_ESSAI] »
- Sous-titre : référence bibliographique complète (auteurs, journal, année, DOI)
- Date de l'analyse
- Mention : « Document généré par IA »
- Perspective : mentionner impérativement que l'analyse a été effectuée suivant une perspective de recherche de preuves formelles, au-delà de tout doute raisonnable, de l’intérêt clinique du traitement. L'analyse évalue la robustesse des résultats, charge à l'utilisateur de conclure sur la place du traitement évalué dans la stratégie thérapeutique.
  

## 1. Synthèse exécutive (1 page max)

À mettre en premier après la page de garde — c'est ce que liront les décideurs pressés.

- **Question évaluée** : 1 phrase
- **Principaux résultats démontrés**
- **Principales limites / incertitudes résiduelles**


## 2. Description de l'étude

### 2.1 Contexte et rationnel
- Pathologie, besoin médical non couvert, mécanisme d'action
- Place attendue du traitement dans la stratégie thérapeutique

### 2.2 Méthodologie (PICOT-S)
- Population (critères I/E, n randomisés, n analysés)
- Intervention (molécule, dose, schéma, durée)
- Comparateur (nature, justification, dose, durée)
- Critères de jugement (principal, secondaires hiérarchisés, exploratoires, sécurité)
- Timing (suivi, dates)
- Setting (pays, centres, contexte)

### 2.3 Analyse statistique
- Hypothèses (taille d'effet attendue, puissance, alpha)
- Gestion de la multiplicité, liste des critères avec gestion de la multiplicité (mention que les autres critères ne permettant pas d'inférer l'effet du traitement)
- Population d'analyse principale (ITT, mITT), gestion des événements intercurrents
- Gestion des analyses intermédiaire (contrôle du risque alpha global, préservation de l’intégrité scientifique de l'essai) 
- Gestion des données manquantes
- Mentionne comme références de cette section les chapitres suivant du livre blanc de la Société Française de Pharmacologie et de Thérapeutique :
  - [Le contrôle du risque alpha global](https://sfpt-fr.org/livreblancmethodo/part7/file_0.htm)
  - [L’analyse finale et les analyses intermédiaires](https://sfpt-fr.org/livreblancmethodo/part8/file_0.htm)
  - [ Lecture critique des essais thérapeutiques - 6 Le contrôle du risque d’erreur statistique ](https://sfpt-fr.org/livreblancmethodo/part4/file_15.htm)


## 3. Évaluation du risque de biais 

- Justification 1-2 phrases par domaine
- Jugement global
- Mentionne comme références de cette section les chapitres suivant du livre blanc de la Société Française de Pharmacologie et de Thérapeutique :
  - [Les biais de l’essai de supériorité](https://sfpt-fr.org/livreblancmethodo/part6/file_0.htm)
  - [ Lecture critique des essais thérapeutiques - 7 Évaluation du risque de biais ](https://sfpt-fr.org/livreblancmethodo/part4/file_36.htm)

## 4. Evaluation de la pertinence clinique
- pertinence du comparateur (est-ce un comparateur loyal, correspondant ua meilleur traitement disponible à la date d'aujourd'hui ? quel est l'essai ou les essai qui ont démontré son bénéfice clinique dans cette indication)
- pertinence des critères de jugement (sont-ce des critères cliniques et non pas intermédiaires ?)
- pertinence de la taille de l'effet (la magnitude de l'effet est-elle suffisante pour être cliniquement pertinente ? en particulier vis à vis de la lourdeur du traitement, de sa safety et de la pertinence clinique du critère) 
- pertinence des patients étudiés (la population inclus n'est pas hyper-sélectionnée par rapport à la population visée ? En cas de run-in avant randomisation, quel est son retentissement sur la pertinence clinique des patients inclus ?)
- Mentionne comme références de cette section les chapitres suivant du livre blanc de la Société Française de Pharmacologie et de Thérapeutique :
  - [Évaluation de la pertinence clinique](https://sfpt-fr.org/livreblancmethodo/part21/file_0.htm)
  - [Lecture critique des essais thérapeutiques - 10 Évaluation de la pertinence clinique (clinical relevance)](https://sfpt-fr.org/livreblancmethodo/part4/file_46.htm)

## 5. Résultats par catégorie

Présenter les résultats par catégorie selon `classification-resultats.md`.

Pour chaque catégorie, tableau standardisé :

|  Critère de jugement | Résultat | Signification statistique | Risque de biais | Pertinence clinique |
|---|---|---|---|---|
| … | … | … | … | … |

Définition des colonnes:
- colonne 'Résultat' : ne mentionner que la taille de l'effet et son intervalle de confiance
- colonne 'Signification statistique' : indiquer si le résultat est statistiquement significatif en terme de risque alpha global, préciser al p value et le seuil de la signification statistique compte tenu de la méthode de gestion de la multiplicité utilisé. En cas de résultat que nominalement significatif, mentionner explicitement : non statistiquement significatif en terme de risque alpha global.
- colonne 'Pertinence clinique' : mentionner la pertinence du critère, du comparateur, de la taille de l'effet traitement et la balance bénéfice risque.

## 6. Sécurité et balance bénéfice/risque

- Effets indésirables susceptible de contrebalancer le bénéfice quantitativement ou qualitativement
- Effets indésirables d'intérêt particulier
- Décès liés au traitement
- Calcul explicite de la balance B/R sur les principaux critères
- Mentionne comme références de cette section les chapitres suivant du livre blanc de la Société Française de Pharmacologie et de Thérapeutique :
  - [La balance bénéfice-risque](https://sfpt-fr.org/livreblancmethodo/part12/file_0.htm)

## 7. Limites et points de vigilance

- Validité externe (généralisation à la population française)
- Comparateur (loyal vs dépassé)
- Homogénéité de l'effet pour tous les patients inclus (avec une vigilance particulière pour l'inclusion de patients pour lesquels le bénéfice attendu était spéculatif)
- Conflits d'intérêt et rôle du sponsor
- Cohérence protocole / SAP / publication
- Données manquantes
- Suivi insuffisant pour des outcomes à long terme

## 8. Conclusion factuelle


Réponse explicite à : Quels résultats sont **suffisamment probants** pour démontrer l’intérêt clinique du traitement étudié ?

Ne pas se positionner sur l’intérêt ou pas du traitement dans la stratégie thérapeutique. 

---

## Style éditorial

- Phrases courtes, vocabulaire précis
- Pas de marketing, pas d'emphase superflue
- Chaque chiffre cité doit pointer vers une table/figure de l'article
- Les résultats NS sont présentés comme « non démontrés », **pas** comme « équivalents »
- Quand une donnée manque, l'écrire : « Non rapporté dans l'article »
